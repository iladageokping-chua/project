package com.example.project_diary_cp213

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
